"""Встроенная функция hash()"""

print(hash('http://stackoverflow.com'))  # -> -8823307079175196, а потом -8860150030631583233 и т.д.

# а такие результаты у других разработчиков
# hash('http://stackoverflow.com') Result: 1934711907

# hash('http://stackoverflow.com') Result: -5768830964305142685

# сделаем выводы!
