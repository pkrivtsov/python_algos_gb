# Вариант 1. Использование встроенного типа данных complex:
#4.5 + 0.9j

a = input()
b = input()
a = complex(a)
b = complex(b)
suma = a + b
mult = a * b
print(suma)
print(mult)
